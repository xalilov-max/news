from django.shortcuts import render, get_object_or_404
from .models import Category, News

def home(request):
    categories = Category.objects.all()
    news = News.objects.all()
    return render(request, 'news/home.html', {'categories': categories, 'news': news})

def category_news(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    news = News.objects.filter(category=category)
    return render(request, 'news/category_news.html', {'category': category, 'news': news})

def news_detail(request, news_id):
    news_item = get_object_or_404(News, pk=news_id)
    return render(request, 'news/news_detail.html', {'news_item': news_item})
